import React from 'react'

const Hero = () => {
  return (
    <div>
        <div>
            10 X Academy
        </div>
        <div>
            <div>
                <span>Publish</span>
                <span>Comments</span>
                <span>History</span>
                <span>Logout</span>
            </div>
            <div>
                <p>What is lorem Ipsum</p>
                <p> Lorem200
                </p>
            </div>
        </div>
    </div>
  )
}

export default Hero